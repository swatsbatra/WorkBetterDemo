define(['ojs/ojcore', 'knockout', 'jquery', 'ojs/./ojknockout'],
        function (oj, ko, $)
        {
            // app wide stuff
        });
